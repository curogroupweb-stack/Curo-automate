# CURO Automate V0.1 — copia física independiente

Este paquete NO modifica CURO Platform ni el MVP existente en AppDeploy.

## Ejecutar en Mac/Windows
1. Instalar Node.js 20+.
2. Abrir Terminal en esta carpeta.
3. `npm install`
4. `npm run dev`
5. Abrir la URL local indicada por Vite.

## Incluido
- Home pública CURO Automate responsive.
- Paleta CURO y degradados.
- Hero, capacidades, ideas por profesión, funcionamiento, CURO Agent y Plan Gratis 2 automatizaciones.
- Modal de acceso demostrativo.
- Estructura preparada para Vercel.

## Pendiente de conexión real
La autenticación, persistencia, correo, IA y ejecución real de automatizaciones deben conectarse a Supabase/proveedores. No se presentan como funcionales en esta copia para evitar simular capacidades inexistentes.

## Siguiente versión
Conectar Supabase Auth + base de datos, reconstruir panel privado, conocimiento/RAG, aprobaciones y flujo real de correo.
